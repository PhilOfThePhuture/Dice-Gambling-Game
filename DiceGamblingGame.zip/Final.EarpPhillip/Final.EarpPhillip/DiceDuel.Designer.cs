﻿namespace Final.EarpPhillip
{
    partial class DiceDuel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.picYourDice = new System.Windows.Forms.PictureBox();
            this.picCPUDice = new System.Windows.Forms.PictureBox();
            this.lblYou = new System.Windows.Forms.Label();
            this.lblCPUCoins = new System.Windows.Forms.Label();
            this.lblYourCoins = new System.Windows.Forms.Label();
            this.lblCPU = new System.Windows.Forms.Label();
            this.lblWinPercent = new System.Windows.Forms.Label();
            this.btnBet5 = new System.Windows.Forms.Button();
            this.btnBet10 = new System.Windows.Forms.Button();
            this.btnBet20 = new System.Windows.Forms.Button();
            this.btnRoll = new System.Windows.Forms.Button();
            this.lblTotalBet = new System.Windows.Forms.Label();
            this.lblWinOrLose = new System.Windows.Forms.Label();
            this.lblNotEnoughCoins = new System.Windows.Forms.Label();
            this.btnClearBet = new System.Windows.Forms.Button();
            this.btnGameReset = new System.Windows.Forms.Button();
            this.lblPlayerRoll = new System.Windows.Forms.Label();
            this.lblCompRoll = new System.Windows.Forms.Label();
            this.lblPlayerBet = new System.Windows.Forms.Label();
            this.lblCPUBet = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picYourDice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCPUDice)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.Location = new System.Drawing.Point(263, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(0, 37);
            this.lblWelcome.TabIndex = 0;
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picYourDice
            // 
            this.picYourDice.Location = new System.Drawing.Point(65, 105);
            this.picYourDice.Name = "picYourDice";
            this.picYourDice.Size = new System.Drawing.Size(350, 303);
            this.picYourDice.TabIndex = 1;
            this.picYourDice.TabStop = false;
            // 
            // picCPUDice
            // 
            this.picCPUDice.Location = new System.Drawing.Point(491, 105);
            this.picCPUDice.Name = "picCPUDice";
            this.picCPUDice.Size = new System.Drawing.Size(350, 303);
            this.picCPUDice.TabIndex = 1;
            this.picCPUDice.TabStop = false;
            // 
            // lblYou
            // 
            this.lblYou.AutoSize = true;
            this.lblYou.Location = new System.Drawing.Point(65, 78);
            this.lblYou.Name = "lblYou";
            this.lblYou.Size = new System.Drawing.Size(0, 20);
            this.lblYou.TabIndex = 2;
            // 
            // lblCPUCoins
            // 
            this.lblCPUCoins.AutoSize = true;
            this.lblCPUCoins.Location = new System.Drawing.Point(726, 78);
            this.lblCPUCoins.Name = "lblCPUCoins";
            this.lblCPUCoins.Size = new System.Drawing.Size(0, 20);
            this.lblCPUCoins.TabIndex = 3;
            // 
            // lblYourCoins
            // 
            this.lblYourCoins.AutoSize = true;
            this.lblYourCoins.Location = new System.Drawing.Point(302, 78);
            this.lblYourCoins.Name = "lblYourCoins";
            this.lblYourCoins.Size = new System.Drawing.Size(0, 20);
            this.lblYourCoins.TabIndex = 4;
            // 
            // lblCPU
            // 
            this.lblCPU.AutoSize = true;
            this.lblCPU.Location = new System.Drawing.Point(491, 78);
            this.lblCPU.Name = "lblCPU";
            this.lblCPU.Size = new System.Drawing.Size(0, 20);
            this.lblCPU.TabIndex = 5;
            // 
            // lblWinPercent
            // 
            this.lblWinPercent.AutoSize = true;
            this.lblWinPercent.Location = new System.Drawing.Point(45, 560);
            this.lblWinPercent.Name = "lblWinPercent";
            this.lblWinPercent.Size = new System.Drawing.Size(0, 20);
            this.lblWinPercent.TabIndex = 6;
            this.lblWinPercent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnBet5
            // 
            this.btnBet5.Location = new System.Drawing.Point(332, 455);
            this.btnBet5.Name = "btnBet5";
            this.btnBet5.Size = new System.Drawing.Size(75, 36);
            this.btnBet5.TabIndex = 7;
            this.btnBet5.UseVisualStyleBackColor = true;
            this.btnBet5.Click += new System.EventHandler(this.btnBet5_Click);
            // 
            // btnBet10
            // 
            this.btnBet10.Location = new System.Drawing.Point(413, 455);
            this.btnBet10.Name = "btnBet10";
            this.btnBet10.Size = new System.Drawing.Size(79, 36);
            this.btnBet10.TabIndex = 8;
            this.btnBet10.UseVisualStyleBackColor = true;
            this.btnBet10.Click += new System.EventHandler(this.btnBet10_Click);
            // 
            // btnBet20
            // 
            this.btnBet20.Location = new System.Drawing.Point(498, 455);
            this.btnBet20.Name = "btnBet20";
            this.btnBet20.Size = new System.Drawing.Size(75, 36);
            this.btnBet20.TabIndex = 9;
            this.btnBet20.UseVisualStyleBackColor = true;
            this.btnBet20.Click += new System.EventHandler(this.btnBet20_Click);
            // 
            // btnRoll
            // 
            this.btnRoll.Location = new System.Drawing.Point(413, 548);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(79, 35);
            this.btnRoll.TabIndex = 10;
            this.btnRoll.UseVisualStyleBackColor = true;
            this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
            // 
            // lblTotalBet
            // 
            this.lblTotalBet.AutoSize = true;
            this.lblTotalBet.Location = new System.Drawing.Point(398, 511);
            this.lblTotalBet.Name = "lblTotalBet";
            this.lblTotalBet.Size = new System.Drawing.Size(0, 20);
            this.lblTotalBet.TabIndex = 11;
            this.lblTotalBet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblWinOrLose
            // 
            this.lblWinOrLose.AutoSize = true;
            this.lblWinOrLose.Location = new System.Drawing.Point(498, 555);
            this.lblWinOrLose.Name = "lblWinOrLose";
            this.lblWinOrLose.Size = new System.Drawing.Size(0, 20);
            this.lblWinOrLose.TabIndex = 12;
            // 
            // lblNotEnoughCoins
            // 
            this.lblNotEnoughCoins.AutoSize = true;
            this.lblNotEnoughCoins.Location = new System.Drawing.Point(266, 420);
            this.lblNotEnoughCoins.Name = "lblNotEnoughCoins";
            this.lblNotEnoughCoins.Size = new System.Drawing.Size(0, 20);
            this.lblNotEnoughCoins.TabIndex = 13;
            // 
            // btnClearBet
            // 
            this.btnClearBet.Location = new System.Drawing.Point(69, 455);
            this.btnClearBet.Name = "btnClearBet";
            this.btnClearBet.Size = new System.Drawing.Size(96, 36);
            this.btnClearBet.TabIndex = 14;
            this.btnClearBet.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnClearBet.UseVisualStyleBackColor = true;
            this.btnClearBet.Click += new System.EventHandler(this.btnClearBet_Click);
            // 
            // btnGameReset
            // 
            this.btnGameReset.Location = new System.Drawing.Point(701, 548);
            this.btnGameReset.Name = "btnGameReset";
            this.btnGameReset.Size = new System.Drawing.Size(140, 35);
            this.btnGameReset.TabIndex = 15;
            this.btnGameReset.UseVisualStyleBackColor = true;
            this.btnGameReset.Click += new System.EventHandler(this.btnGameReset_Click);
            // 
            // lblPlayerRoll
            // 
            this.lblPlayerRoll.AutoSize = true;
            this.lblPlayerRoll.Location = new System.Drawing.Point(171, 463);
            this.lblPlayerRoll.Name = "lblPlayerRoll";
            this.lblPlayerRoll.Size = new System.Drawing.Size(0, 20);
            this.lblPlayerRoll.TabIndex = 17;
            // 
            // lblCompRoll
            // 
            this.lblCompRoll.AutoSize = true;
            this.lblCompRoll.Location = new System.Drawing.Point(579, 463);
            this.lblCompRoll.Name = "lblCompRoll";
            this.lblCompRoll.Size = new System.Drawing.Size(0, 20);
            this.lblCompRoll.TabIndex = 18;
            // 
            // lblPlayerBet
            // 
            this.lblPlayerBet.AutoSize = true;
            this.lblPlayerBet.Location = new System.Drawing.Point(270, 510);
            this.lblPlayerBet.Name = "lblPlayerBet";
            this.lblPlayerBet.Size = new System.Drawing.Size(0, 20);
            this.lblPlayerBet.TabIndex = 19;
            // 
            // lblCPUBet
            // 
            this.lblCPUBet.AutoSize = true;
            this.lblCPUBet.Location = new System.Drawing.Point(525, 509);
            this.lblCPUBet.Name = "lblCPUBet";
            this.lblCPUBet.Size = new System.Drawing.Size(0, 20);
            this.lblCPUBet.TabIndex = 20;
            // 
            // DiceDuel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(924, 592);
            this.Controls.Add(this.lblCPUBet);
            this.Controls.Add(this.lblPlayerBet);
            this.Controls.Add(this.lblCompRoll);
            this.Controls.Add(this.lblPlayerRoll);
            this.Controls.Add(this.btnGameReset);
            this.Controls.Add(this.btnClearBet);
            this.Controls.Add(this.lblNotEnoughCoins);
            this.Controls.Add(this.lblWinOrLose);
            this.Controls.Add(this.lblTotalBet);
            this.Controls.Add(this.btnRoll);
            this.Controls.Add(this.btnBet20);
            this.Controls.Add(this.btnBet10);
            this.Controls.Add(this.btnBet5);
            this.Controls.Add(this.lblWinPercent);
            this.Controls.Add(this.lblCPU);
            this.Controls.Add(this.lblYourCoins);
            this.Controls.Add(this.lblCPUCoins);
            this.Controls.Add(this.lblYou);
            this.Controls.Add(this.picCPUDice);
            this.Controls.Add(this.picYourDice);
            this.Controls.Add(this.lblWelcome);
            this.Name = "DiceDuel";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.DiceDuel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picYourDice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCPUDice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.PictureBox picYourDice;
        private System.Windows.Forms.PictureBox picCPUDice;
        private System.Windows.Forms.Label lblYou;
        private System.Windows.Forms.Label lblCPUCoins;
        private System.Windows.Forms.Label lblYourCoins;
        private System.Windows.Forms.Label lblCPU;
        private System.Windows.Forms.Label lblWinPercent;
        private System.Windows.Forms.Button btnBet5;
        private System.Windows.Forms.Button btnBet10;
        private System.Windows.Forms.Button btnBet20;
        private System.Windows.Forms.Button btnRoll;
        private System.Windows.Forms.Label lblTotalBet;
        private System.Windows.Forms.Label lblWinOrLose;
        private System.Windows.Forms.Label lblNotEnoughCoins;
        private System.Windows.Forms.Button btnClearBet;
        private System.Windows.Forms.Button btnGameReset;
        private System.Windows.Forms.Label lblPlayerRoll;
        private System.Windows.Forms.Label lblCompRoll;
        private System.Windows.Forms.Label lblPlayerBet;
        private System.Windows.Forms.Label lblCPUBet;
    }
}

