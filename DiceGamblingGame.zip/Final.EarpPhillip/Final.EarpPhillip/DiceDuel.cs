﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final.EarpPhillip
{
    public partial class DiceDuel : Form
    {
        int playerCoins = 200;
        int compCoins = 200;
        int playerBet = 0;
        int compBet = 0;
        int fullBet = 0;
        double winPercent = 0;
        double losses = 0;
        double wins = 0;
        double totalGames = 0;
        Stack<string> winLoss = new Stack<string>();
        public DiceDuel()
        {
            InitializeComponent();
        }

        private void DiceDuel_Load(object sender, EventArgs e)
        {
            lblWelcome.Text = "Welcome to Dice Duels!";
            lblYou.Text = "You:";
            lblCPU.Text = "CPU:";
            this.SetLabels();
            picCPUDice.ImageLocation = "http://3.bp.blogspot.com/-hPEkwi1p0OU/T2keDEskKsI/AAAAAAAACTc/EtsAZQak-ZA/s1600/dice2.gif";
            picYourDice.ImageLocation = "http://3.bp.blogspot.com/-hPEkwi1p0OU/T2keDEskKsI/AAAAAAAACTc/EtsAZQak-ZA/s1600/dice2.gif";
            btnBet5.Text = "Add 5";
            btnBet10.Text = "Add 10";
            btnBet20.Text = "Add 20";
            btnClearBet.Text = "Clear Bet";
            btnGameReset.Text = "Reset Game";
            btnRoll.Text = "Roll!";
        }

        private void btnBet5_Click(object sender, EventArgs e)
        {
            if (playerCoins < 5 || compCoins < 5)
            {
                lblNotEnoughCoins.Text = "You or the computer don't have enough coins for that bet.";
            }
            else
            {
                playerBet += 5;
                compBet += 5;
                fullBet = playerBet + compBet;
                playerCoins -= 5;
                compCoins -= 5;
                lblWinOrLose.Text = "";
                lblNotEnoughCoins.Text = "";
                this.SetLabels();
            }
        }

        private void btnBet10_Click(object sender, EventArgs e)
        {
            if (playerCoins < 10 || compCoins < 10)
            {
                lblNotEnoughCoins.Text = "You or the computer don't have enough coins for that bet.";
            }
            else
            {
                playerBet += 10;
                compBet += 10;
                fullBet = playerBet + compBet;
                playerCoins -= 10;
                compCoins -= 10;
                lblWinOrLose.Text = "";
                lblNotEnoughCoins.Text = "";
                this.SetLabels();
            }
        }

        private void btnBet20_Click(object sender, EventArgs e)
        {
            if (playerCoins < 20 || compCoins < 20)
            {
                lblNotEnoughCoins.Text = "You or the computer don't have enough coins for that bet.";
            }
            else
            {
                playerBet += 20;
                compBet += 20;
                fullBet = playerBet + compBet;
                playerCoins -= 20;
                compCoins -= 20;
                lblWinOrLose.Text = "";
                lblNotEnoughCoins.Text = "";
                this.SetLabels();
            }
        }

        private void btnClearBet_Click(object sender, EventArgs e)
        {
            playerCoins = playerCoins + playerBet;
            compCoins = compCoins + compBet;
            playerBet = 0;
            compBet = 0;
            fullBet = 0;
            lblWinOrLose.Text = "";
            lblNotEnoughCoins.Text = "";
            this.SetLabels();
        }

        private void btnRoll_Click(object sender, EventArgs e)
        {
            playerBet = 0;
            compBet = 0;
            Random rnd = new Random();
            int compDice = rnd.Next(1, 7);
            int yourDice = rnd.Next(1, 7);
            lblNotEnoughCoins.Text = "";
            while (compDice == yourDice)
            {
                compDice = rnd.Next(1, 7);
                yourDice = rnd.Next(1, 7);
            }
            if (compDice > yourDice)
            {
                lblWinOrLose.Text = "You Lose!";
                compCoins += fullBet;
                lblTotalBet.Text = "0";
                fullBet = 0;
                winLoss.Push("loss");
                losses += 1;
            }
            else
            {
                lblWinOrLose.Text = "You Win!";
                playerCoins += fullBet;
                lblTotalBet.Text = "0";
                fullBet = 0;
                winLoss.Push("win");
                wins += 1;
            }
            totalGames = wins + losses;
            double winRate = wins / totalGames;
            winPercent = Math.Round(winRate * 100, 2);
            this.SetLabels();
            lblPlayerRoll.Text = "You Rolled: " + yourDice;
            lblCompRoll.Text = "The CPU Rolled: " + compDice;
            picYourDice.ImageLocation = this.PlayerDice(yourDice);
            picCPUDice.ImageLocation = this.CPUDice(compDice);
            if (compCoins == 0)
            {
                MessageBox.Show("You have won all of the CPU's coins. Please press the Reset Game button to continue playing.");
            }
            if (playerCoins == 0)
            {
                MessageBox.Show("You have lost all of your coins. Please press the Reset Game button to continue playing.");
            }
        }

        private void btnGameReset_Click(object sender, EventArgs e)
        {
            playerCoins = 200;
            compCoins = 200;
            playerBet = 0;
            compBet = 0;
            winPercent = 0;
            fullBet = 0;
            losses = 0;
            wins = 0;
            winLoss.Clear();
            lblWinOrLose.Text = "";
            lblWelcome.Text = "Welcome to Dice Duels!";
            this.SetLabels();
            lblNotEnoughCoins.Text = "";
            lblPlayerRoll.Text = "";
            lblCompRoll.Text = "";
            picCPUDice.ImageLocation = "http://3.bp.blogspot.com/-hPEkwi1p0OU/T2keDEskKsI/AAAAAAAACTc/EtsAZQak-ZA/s1600/dice2.gif";
            picYourDice.ImageLocation = "http://3.bp.blogspot.com/-hPEkwi1p0OU/T2keDEskKsI/AAAAAAAACTc/EtsAZQak-ZA/s1600/dice2.gif";
        }

        private void SetLabels()
        {
            lblYourCoins.Text = "Your Coins: " + playerCoins;
            lblCPUCoins.Text = "CPU Coins: " + compCoins;
            lblWinPercent.Text = "Win Percentage: " + winPercent + "%";
            lblTotalBet.Text = "Total Bet: " + fullBet;
            lblPlayerBet.Text = "Your Bet: " + playerBet;
            lblCPUBet.Text = "CPU Bet: " + compBet;
        }

        public string PlayerDice(int playerRoll)
        {
            string playerDiceIMG = "";
            if (playerRoll == 1)
            {
                playerDiceIMG = "https://i.imgur.com/xar77dd.png";
            }
            if (playerRoll == 2)
            {
                playerDiceIMG = "https://i.imgur.com/tW0OVcn.png";
            }
            if (playerRoll == 3)
            {
                playerDiceIMG = "https://i.imgur.com/Yxu8Dd0.png";
            }
            if (playerRoll == 4)
            {
                playerDiceIMG = "https://i.imgur.com/qOBob1K.png";
            }
            if (playerRoll == 5)
            {
                playerDiceIMG = "https://i.imgur.com/nleqZuG.png";
            }
            if (playerRoll == 6)
            {
                playerDiceIMG = "https://i.imgur.com/0O8R8eE.png";
            }
            return playerDiceIMG;
        }

        public string CPUDice(int compRoll)
        {
            string compDiceIMG = "";
            if (compRoll == 1)
            {
                compDiceIMG = "https://i.imgur.com/xar77dd.png";
            }
            if (compRoll == 2)
            {
                compDiceIMG = "https://i.imgur.com/tW0OVcn.png";
            }
            if (compRoll == 3)
            {
                compDiceIMG = "https://i.imgur.com/Yxu8Dd0.png";
            }
            if (compRoll == 4)
            {
                compDiceIMG = "https://i.imgur.com/qOBob1K.png";
            }
            if (compRoll == 5)
            {
                compDiceIMG = "https://i.imgur.com/nleqZuG.png";
            }
            if (compRoll == 6)
            {
                compDiceIMG = "https://i.imgur.com/0O8R8eE.png";
            }
            return compDiceIMG;
        }
    }
}
